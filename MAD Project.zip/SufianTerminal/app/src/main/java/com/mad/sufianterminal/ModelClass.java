package com.mad.sufianterminal;

public class ModelClass {

}