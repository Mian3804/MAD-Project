package com.mad.sufianterminal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;



import org.json.JSONException;
import org.json.JSONObject;

public class lti extends AppCompatActivity {
TextView t1;
ListView listView;

String[] cities ={ "Morning: 10:00 AM", "Afternoon: 02:00 PM","Evening: 04:00 PM","Night: 08:00 PM"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lti);

        t1= findViewById(R.id.t1);
        t1.setText(getIntent().getExtras().getString("nam"));



        listView = findViewById(R.id.list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(lti.this, android.R.layout.simple_dropdown_item_1line,cities);
        listView.setAdapter(adapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //  Toast.makeText(getApplicationContext(), "This Position is " + i,Toast.LENGTH_SHORT).show();

                // for listview intent
                String str = listView.getAdapter().getItem(i).toString();
                Intent inte = new Intent(getApplicationContext(),Payment.class);
//                inte.putExtra("name1", str);
                startActivity(inte);
                finish();



                // this line use listview without intent
//                if(i==0)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Karachi",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==1)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Islamabad",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==2)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Jhang",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==3)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Faisalbad",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==4)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Mianwali",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==5)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Sialkot",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==6)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Multan",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==7)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Peshawar",Toast.LENGTH_SHORT).show();
//                }

            }
        });

//
//        cd1 = (CardView) findViewById(R.id.cd1);
//        cd2 = (CardView) findViewById(R.id.cd2);
//
//        cd1.setOnClickListener(this);
//        cd2.setOnClickListener(this);

    }



//    @Override
//    public void onClick(View v)
//    {
//        Intent i;
//
//        switch (v.getId())
//        {
//            case R.id.cd1:
//                i = new Intent(this,aboutus.class);
//                startActivity(i);
//                break;
//            case R.id.cd2:
//                i = new Intent(this,aboutus.class);
//                startActivity(i);
//                break;
//        }
//    }

}