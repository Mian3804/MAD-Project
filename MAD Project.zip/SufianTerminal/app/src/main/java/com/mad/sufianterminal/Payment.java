package com.mad.sufianterminal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Payment extends AppCompatActivity {

    TextView txtpay,txtpay0;
    Button submit;
    EditText name, password, email, contact, date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

//        txtpay= findViewById(R.id.txtpay);
//        txtpay.setText(getIntent().getExtras().getString("name1"));



        name = (EditText) findViewById(R.id.editText1);
        password = (EditText) findViewById(R.id.editText2);
        email = (EditText) findViewById(R.id.editText3);
        date = (EditText) findViewById(R.id.editText4);
        contact = (EditText) findViewById(R.id.editText5);
        submit = (Button) findViewById(R.id.button);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().isEmpty() || password.getText().toString().isEmpty() || email.getText().toString().isEmpty() || date.getText().toString().isEmpty()
                        || contact.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter the data", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Thanks for booking\nName -  " + name.getText().toString() + " \n" + "Direction -  " + password.getText().toString()
                            + " \n" + "Trevelling Time -  " + email.getText().toString() + " \n" + "Trevelling Date -  " + date.getText().toString()
                            + " \n" + "Contact -  " + contact.getText().toString()+ " \nConfirmation message will send you", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Payment.this,lti.class));
                    finish();

                }
            }
        });



    }
}