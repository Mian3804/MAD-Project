package com.mad.sufianterminal;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.mad.sufianterminal.databinding.ActivityMainBinding;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private Button btnLogout;
    private Session session;
    ListView lv,list;

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle actionBarDrawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        // Check Session for Login and Logout

        session = new Session(this);
        if(!session.loggedin()){
            logout();
        }
        // Login and Logout Session


        lv=findViewById(R.id.lv);
        String []name={"Lahore to Karachi","Lahore to Islamabad","Lahore to Jhang","Lahore to Faisalabad","Lahore to Mianwali","Lahore to Sialkot","Lahore to Multan","Lahore to Peshawar"};
        Integer[]img={R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop,R.drawable.b1uscrop};
        MyListAdapter adapter=new MyListAdapter(this, name,img);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //  Toast.makeText(getApplicationContext(), "This Position is " + i,Toast.LENGTH_SHORT).show();

                // for listview intent
                String str = lv.getAdapter().getItem(i).toString();
                Intent inte = new Intent(getApplicationContext(),lti.class);
                inte.putExtra("nam", str);
                startActivity(inte);






                // this line use listview without intent
//                if(i==0)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Karachi",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==1)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Islamabad",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==2)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Jhang",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==3)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Faisalbad",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==4)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Mianwali",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==5)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Sialkot",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==6)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Multan",Toast.LENGTH_SHORT).show();
//                }
//
//                if(i==7)
//                {
//                    Intent intent = new Intent(MainActivity.this, lti.class);
//                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), "Lahore to Peshawar",Toast.LENGTH_SHORT).show();
//                }

            }
        });



        // nav bar onclick
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.nav_home:
                        Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this,MainActivity.class));
                        finish();
                        return true;


                    case R.id.nav_gallery:
                        Toast.makeText(MainActivity.this, "Face Detection", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this,facedetection.class));
                        return true;

                    case R.id.nav_slideshow:
                        Toast.makeText(MainActivity.this, "Terminal Location", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this,livelocation.class));
                        return true;

                    case R.id.nav_complain:
                        Toast.makeText(MainActivity.this, "Terminal Location", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this,complain.class));
                        return true;

                    case R.id.nav_share:
                        Toast.makeText(MainActivity.this, "Share", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        String app_url="https://play.google.com/";
                        i.putExtra(Intent.EXTRA_TEXT,app_url);
                        startActivity(Intent.createChooser(i,"Share Via"));
                }
                return true;
            }
        });


    }

    public class MyListAdapter extends ArrayAdapter<String> {

        private final Activity context;
        private final String[] name;
        private final Integer[] img;

        public MyListAdapter(Activity context, String[] name,Integer[] img) {
            super(context, R.layout.customlist, name);
            // TODO Auto-generated constructor stub

            this.context=context;
            this.img = img;
            this.name=name;
        }

        public View getView(int position, View view, ViewGroup parent) {
            LayoutInflater inflater=context.getLayoutInflater();
            View rowView=inflater.inflate(R.layout.customlist, null,true);

            TextView titleText = (TextView) rowView.findViewById(R.id.title);
            ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);

            titleText.setText(name[position]);
            imageView.setImageResource(img[position]);

            return rowView;

        };
    }


// Destroy Logout Seesion
    private void logout(){
        session.setLoggedin(false);
        finish();
        startActivity(new Intent(MainActivity.this,LoginActivity.class));
    }

    // For Logout in Menu of 3 dots
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                logout();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    // For Logout in Menu of 3 dots


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}