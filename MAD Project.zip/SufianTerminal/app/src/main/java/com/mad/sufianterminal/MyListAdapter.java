package com.mad.sufianterminal;

public class MyListAdapter {
    public MyListAdapter(MainActivity mainActivity, String[] name, Integer[] img) {
    }
}
